package com.example.phase2_main.repository;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class messageRepository {
    public static void sendMessage(String thisUsername , Connection connection , String targetUser ){

    }
}
